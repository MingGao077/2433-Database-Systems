-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: dbms-part3
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coordposition_productionasset`
--

DROP TABLE IF EXISTS `coordposition_productionasset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coordposition_productionasset` (
  `PremiumCode` varchar(50) DEFAULT NULL,
  `Associate_id` int DEFAULT NULL,
  `SitCode` varchar(50) DEFAULT NULL,
  `IssueDate` date DEFAULT NULL,
  `ContractType` varchar(50) DEFAULT NULL,
  `ContractSignDate` date DEFAULT NULL,
  `ContractProcessDate` date DEFAULT NULL,
  `ManagerContractEndDate` date DEFAULT NULL,
  `ProductionCreditSplitPercentage` decimal(5,2) DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `TerritoryName` varchar(255) DEFAULT NULL,
  `TerritoryStartDate` date DEFAULT NULL,
  `TerritoryEndDate` date DEFAULT NULL,
  `TerritoryCoordinatorEndDate` date DEFAULT NULL,
  `Level` int DEFAULT NULL,
  `LevelName` varchar(255) DEFAULT NULL,
  `LevelAbbreviation` varchar(10) DEFAULT NULL,
  `StateCoordinatorsEndDate` date DEFAULT NULL,
  KEY `PremiumCode` (`PremiumCode`),
  KEY `Associate_id` (`Associate_id`),
  CONSTRAINT `coordposition_productionasset_ibfk_1` FOREIGN KEY (`PremiumCode`) REFERENCES `contractpremium` (`PremiumCode`),
  CONSTRAINT `coordposition_productionasset_ibfk_2` FOREIGN KEY (`Associate_id`) REFERENCES `associate` (`Associate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coordposition_productionasset`
--

LOCK TABLES `coordposition_productionasset` WRITE;
/*!40000 ALTER TABLE `coordposition_productionasset` DISABLE KEYS */;
/*!40000 ALTER TABLE `coordposition_productionasset` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-04 11:50:52
